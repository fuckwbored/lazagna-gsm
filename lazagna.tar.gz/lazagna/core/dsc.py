import time

time.sleep(0.2)
print("This tool was created only for informational and educational purpose")
print("Author will not be responsible for any action performed by any reader.")
time.sleep(4.1)
print("Close this window")
