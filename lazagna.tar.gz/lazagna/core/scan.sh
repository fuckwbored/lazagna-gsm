sudo grgsm_scanner -v -b GSM900 --debug --args=rtl
