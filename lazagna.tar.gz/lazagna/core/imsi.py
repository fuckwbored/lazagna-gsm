import os

os.system ("cd IMSI-catcher/ && sudo python3 simple_IMSI-catcher.py -s")

